using DaysDifference.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Xunit;
using Xunit.Sdk;

namespace UnitTest.DaysDifference
{
    [TestClass]
    public class UTCalculateDays
    {
        //public static IEnumerable<object[]> TestData()
        //{
        //    //yield return new[] { new DaysCalculaterVM { StartDate = "2022-08-26", EndDate = "2022-08-26" }, true,  1 };
        //    //yield return new[] { new DaysCalculaterVM { StartDate = "2021-01-01", EndDate = "2025-08-21" }, true, 1649 };
        //    var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TestData.json");
        //    var json = File.ReadAllText(filePath);
        //    var jobject = JObject.Parse(json);
        //    var testData = jobject["testData"]?.ToObject<IEnumerable<TestInputDataModel>>();

        //    foreach (var input in testData ?? Enumerable.Empty<TestInputDataModel>())
        //    {
        //        yield return new[] { input };
        //    }
        //}

        [TestMethod]
        [DataRow("2022-08-26", "2022-08-26", true, 1)] //Same Day
        [DataRow("2023-08-26", "2022-08-26", false, 0)] // Start Date Grater than End Date
        [DataRow("1990-01-01", "2025-08-21", true, 13017)] // 35 years
        [DataRow("1924-01-01", "2025-12-21", true, 37246)] // 100 years
        [DataRow("2022-08-26", "2023-08-26", true, 366)] // One Exact Year
        [DataRow("2022-08-10", "2022-08-26", true, 17)] // Same Year Same Month Different Days
        [DataRow("2022-02-15", "2022-09-26", true, 224)] // Same Year Different Month
        public void TestDateDifference(string startDate, string endDate, bool expectedResponse, int expectedDays)
        {
            DaysCalculaterVM daysCalculaterVM = new DaysCalculaterVM() { StartDate = startDate, EndDate = endDate, Days = 0 };
            DaysCalculatorService daysCalculatorService = new DaysCalculatorService();
            bool actualResponse = daysCalculatorService.CalculateDays(daysCalculaterVM);
            Assert.AreEqual(expectedResponse, actualResponse);
            Assert.AreEqual(expectedDays, daysCalculaterVM.Days);
        }
    }
}
