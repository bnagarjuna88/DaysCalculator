﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DaysDifference.Models
{
    public class DaysCalculatorService
    {
        int[] Days31 = new int[] { 1, 3, 5, 7, 8, 10, 12 };
        //Service method which calculates the Date difference
        public bool CalculateDays(DaysCalculaterVM daysCalculaterVM)
        {
            string[] startDateAry = daysCalculaterVM.StartDate.Split('-');
            string[] endDateAry = daysCalculaterVM.EndDate.Split('-');
            int startYear = Convert.ToInt32(startDateAry[0]);
            int endYear = Convert.ToInt32(endDateAry[0]);
            int startYearMonth = Convert.ToInt32(startDateAry[1]);
            int endYearMonth = Convert.ToInt32(endDateAry[1]);
            int startYearDay = Convert.ToInt32(startDateAry[2]);
            int endYearDay = Convert.ToInt32(endDateAry[2]);
            int totalYears = startYear == endYear ? 1 : (endYear - startYear) + 1;
            int days = 0;
            //Validation check if start date grater than end date
            if (startYear > endYear || (startYear == endYear && startYearMonth > endYearMonth) || (startYear == endYear && startYearMonth == endYearMonth && startYearDay > endYearDay))
            {
                return false;
            }
            else
            {
                for (int y = 1; y <= totalYears; y++)
                {
                    int currentYear = startYear + (y - 1);
                    // First year logic
                    if (y == 1)
                    {
                        if (totalYears == 1)
                        {
                            days = CalculateStartYearDays(startYearMonth, startYearDay, days, currentYear, endYearMonth, endYearDay);
                        }
                        else
                        {
                            days = CalculateStartYearDays(startYearMonth, startYearDay, days, currentYear);
                        }
                    }
                    // Last Year Logic
                    else if (y == totalYears)
                    {
                        days = CalculateEndYearDays(endYearMonth, endYearDay, days, currentYear);
                    }
                    else
                    {
                        //Inbetween years logic
                        for (int m = 1; m <= 12; m++)
                        {
                            days = CalculateDaysOnMonths(false, false, false, m, 1, days, currentYear);
                        }
                    }
                }
                daysCalculaterVM.Days = days;
                return true;
            }
        }
        #region Private Methods
        // Caclulates the number of days in end date year
        private int CalculateEndYearDays(int endYearMonth, int endYearDay, int days, int currentYear)
        {
            for (int m = 1; m <= endYearMonth; m++)
            {
                if (m == endYearMonth)
                {
                    //Start date and end date both belong to same year
                    days = CalculateDaysOnMonths(false, true, false, endYearMonth, endYearDay, days, currentYear);
                }
                else
                {
                    //Start date and end date both belong to different year
                    days = CalculateDaysOnMonths(false, false, false, m, 1, days, currentYear);
                }
            }

            return days;
        }
        // Caclulates the number of days in start date year
        private int CalculateStartYearDays(int startYearMonth, int startYearDay, int days, int currentYear, int endYearMonth = 0, int endYearDay = 0)
        {
            int maxMonths = endYearMonth > 0 ? endYearMonth : 12;
            for (int m = startYearMonth; m <= maxMonths; m++)
            {
                if (m == startYearMonth)
                {
                    //Start date and end date both belong to same year
                    if (startYearMonth == endYearMonth)
                    {
                        //Start date and end date both belong to same month and same year
                        days = CalculateDaysOnMonths(true, false, true, startYearMonth, startYearDay, days, currentYear, endYearDay);
                    }
                    else
                    {
                        //Start date and end date both belong to different month but same year
                        days = CalculateDaysOnMonths(true, false, false, startYearMonth, startYearDay, days, currentYear);
                    }
                }
                else if (m == endYearMonth)
                {
                    //Calculates end year end month days
                    days = CalculateDaysOnMonths(false, true, false, endYearMonth, endYearDay, days, currentYear);
                }
                else
                {
                    //Calculates in between full months days
                    days = CalculateDaysOnMonths(false, false, false, m, 1, days, currentYear);
                }
            }

            return days;
        }

        private int CalculateDaysOnMonths(bool runningStartMonth, bool runningEndMonth, bool runningStartSameAsEndMonth, int month, int day, int days, int currentYear, int endDay = 0)
        {
            // Calculates days for start date and end date are of same year and same month
            if (runningStartSameAsEndMonth)
            {
                days += (endDay - day) + 1;
            }
            // Calculates days for start Date first month days
            else if (runningStartMonth)
            {
                days = CalculateStartMonthDays(month, day, days, currentYear);
            }
            // Calculates days for end Date last month days
            else if (runningEndMonth)
            {
                days += day;
            }
            //Calculates full months days
            else
            {
                days = CalculateFullMonthDays(month, days, currentYear);
            }

            return days;
        }

        private int CalculateFullMonthDays(int month, int days, int currentYear)
        {
            // 31 days months
            if (Days31.Contains(month))
            {
                days += 31;
            }
            // february leap year or non leap year calculation
            else if (month == 2)
            {
                if (((currentYear % 4 == 0) && (currentYear % 100 != 0)) || (currentYear % 400 == 0))
                {
                    days += 29;
                }
                else
                {
                    days += 28;
                }
            }
            // 30 days months
            else
            {
                days += 30;
            }

            return days;
        }

        private int CalculateStartMonthDays(int month, int day, int days, int currentYear)
        {
            //start date start month is a 31 day month
            if (Days31.Contains(month))
            {
                days += (31 - day) + 1;
            }
            //start date start month is Feburary
            else if (month == 2)
            {
                if (((currentYear % 4 == 0) && (currentYear % 100 != 0)) || (currentYear % 400 == 0))
                {
                    days += (29 - day) + 1;

                }
                else
                {
                    days += (28 - day) + 1;
                }
            }
            //start date start month is a 30 day month
            else
            {
                days += (30 - day) + 1;
            }

            return days;
        }
        #endregion Private Methods
    }
}
