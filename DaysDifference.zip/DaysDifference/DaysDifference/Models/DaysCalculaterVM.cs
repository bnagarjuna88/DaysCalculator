﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DaysDifference.Models
{
    public class DaysCalculaterVM
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int Days { get; set; }
    }
}
