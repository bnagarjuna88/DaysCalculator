﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using DaysDifference.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace DaysDifference.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetDays(DaysCalculaterVM daysVM)
        {

           DaysCalculatorService daysCalculatorService = new DaysCalculatorService();
            bool response = daysCalculatorService.CalculateDays(daysVM);
            if(!response)
            {
                ViewBag.ErrorMessage = "Start Date cannot be greater than End Date";
            }
            return View("Index", daysVM);
        }

       
    }
}
